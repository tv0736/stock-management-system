# Stock-Inventory-Management-System
This application is built using HTML,CSS,JS,Materialize CSS,AJAX,PHP and SQL
